- Requirements: .NET 4.0 or Windows 8/8.1/2012/R2.

EncrypText: Small App that Encrypt and Decrypt Text with a Password.
TermSrvPatch: Small App that Patch the maximum TCP connections in W8.1/2012R2 to unlimit.
Watermark Editor: External tool for edit the watermark in the corner of Windows 8.1 desktop.