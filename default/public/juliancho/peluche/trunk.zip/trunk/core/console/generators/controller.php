/**
 * Controlador <?php echo $class, PHP_EOL ?>
 * 
 * @category App
 * @package Controllers
 */
class <?php echo $class ?>Controller extends AppController
{

}
