![KumbiaPHP](http://proto.kumbiaphp.com/img/kumbiaphp.png)
Fácil, rápido y en español
---
Bienvenidos a KumbiaPHP Framework 

Preparando la salida de la beta2.

Manual en construcción de la beta2: http://goo.gl/aPgvZ

Rápida introducción a lo nuevo de la beta2 (faltan por añadir): http://wiki.kumbiaphp.com/KumbiaPHP_Framework_Versi%C3%B3n_1.0_Beta2

CRUD en beta2: http://wiki.kumbiaphp.com/Beta2_CRUD_en_KumbiaPHP_Framework

API para usuarios de la beta2: http://www.kumbiaphp.com/api/beta2/

API para los desarrolladores del core: http://www.kumbiaphp.com/api/beta2-dev/

Seguimos trabajando para actualizar bien el phpdoc y tener actualizado el API.


Comunidad
===
http://www.kumbiaphp.com  Web oficial  (pronto en KumbiaPHP http://proto.kumbiaphp.com, bienvenida ayuda con el diseño)

http://wiki.kumbiaphp.com Wiki

http://foro.kumbiaphp.com Foro de KumbiaPHP

http://groups.google.com/group/kumbia/   Grupo de KumbiaPHP +1.500 programadores

irc://irc.freenode.org/#kumbiaphp  IRC

Largo historial de repos durante estos años ;)

cvs(sf.net), svn(sf.net), bzr(launchpad.com) y ahora git(github.com)

Licencia
===
New BSD
